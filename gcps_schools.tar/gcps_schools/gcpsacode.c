#include "gcpsacode.h"

partial_alloc gcpsa_allocation(input_sch_ch_prob* myiscp) {
  int j, nsc, max_slack_school;

  int* coarse;

  process_scp pr_scp;
  input_sch_ch_prob red_scp;
  partial_alloc mcca_alloc;
  partial_alloc gcpsa_alloc;
  partial_alloc gcpsa_copy;

  nsc = myiscp->no_schools;
  coarse = malloc(nsc * sizeof(int));
  for (j = 1; j <= nsc; j++) {
    coarse[j-1] = 0;
  }
  
  pr_scp = process_scp_from_input(myiscp);
  mcca_alloc = mcca_alloc_plus_coarse_cutoffs(&pr_scp, coarse);
  red_scp = reduced_input_scp(myiscp, coarse);
  gcpsa_alloc = simple_GCPS_alloc_with_guide(&red_scp,&mcca_alloc);
  
  max_slack_school = allocation_is_wasteful(&gcpsa_alloc, &pr_scp);

  while (max_slack_school > 0) {
    fprintf(stderr, "We have a wasteful allocation.\n");
    
    destroy_input_sch_ch_prob(red_scp);
    coarse[max_slack_school-1]--;
    red_scp = reduced_input_scp(myiscp, coarse);
    
    gcpsa_copy = copy_of_partial_alloc(&gcpsa_alloc);
    destroy_partial_alloc(gcpsa_alloc);
    gcpsa_alloc = simple_GCPS_alloc_with_guide(&red_scp, &gcpsa_copy);

    max_slack_school = allocation_is_wasteful(&gcpsa_alloc, &pr_scp);
  }

  free(coarse);
  destroy_process_scp(pr_scp);  
  destroy_input_sch_ch_prob(red_scp);

  return gcpsa_alloc;
}
