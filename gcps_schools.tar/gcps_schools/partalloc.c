#include "partalloc.h"

double get_entry(partial_alloc* alloc, int i, int j) {
  double val;
  
  val = dbl_entry(&(alloc->sparse), i, j);

  return val;
}

void set_entry(partial_alloc* alloc, int i, int j, double val) {
  set_dbl_entry(&(alloc->sparse), i, j, val);
}

double get_integer_entry(pure_alloc* alloc, int i, int j) {
  double val;
  
  val = int_entry(&(alloc->sparse), i, j);

  return val;
}

void set_integer_entry(pure_alloc* alloc, int i, int j, int val) {
  set_int_entry(&(alloc->sparse), i, j, val);
}

void increment_entry(partial_alloc* alloc, int i, int j, double incr) {
  increment_dbl_entry(&(alloc->sparse), i, j, incr);
}

int sch_is_active_for_stu(partial_alloc* alloc, int i, int j) {
  return col_is_active_for_row(&(alloc->sparse), i, j);
}

double remaining_time(partial_alloc* alloc) {
  int j, nsc;

  double answer;

  nsc = alloc->no_schools;

  answer = 1.0;
  for (j = 1; j <= nsc; j++) {
    answer -= get_entry(alloc, 1, j);
  }

  return answer;
}

partial_alloc compute_demands(process_scp* myscp, double* cutoffs) {
  int i, j, k, nst, nsc;
  double unfilled_demand;
  partial_alloc answer;
  
  nst = myscp->no_students;
  nsc = myscp->no_schools;

  int* coarse_cutoffs = malloc (nsc * sizeof(int));
  for (j = 1; j <= nsc; j++) {
    coarse_cutoffs[j-1] = floor(cutoffs[j-1]);
  }

  for (i = 1; i <= nst; i++) {
    int l = myscp->no_eligible_schools[i-1];
    j = myscp->preferences[i-1][l-1];
  }

  answer = zero_alloc_for_process_scp(myscp);
  for (i = 1; i <= nst; i++) {
    unfilled_demand = 1.0;
    for (k = 1; k <= myscp->no_eligible_schools[i-1]; k++) {
      if (unfilled_demand > 0.000000001) {
	j = myscp->preferences[i-1][k-1];
	if (get_priority(myscp, i, j) > coarse_cutoffs[j-1]) {
	  set_entry(&answer, i, j, unfilled_demand);
	}
	else if (get_priority(myscp, i, j) == coarse_cutoffs[j-1]) {
	  set_entry(&answer, i, j, min(unfilled_demand,
				      1.0 - (cutoffs[j-1] - (double)coarse_cutoffs[j-1])));
	}
	unfilled_demand -= get_entry(&answer, i, j);
      }
    }
  }

  free(coarse_cutoffs);

  return answer;
}

double get_total_demand_for_student(process_scp* myscp,
				    partial_alloc* alloc, int i) {
  int j, k;
  double answer;

  answer = 0.0;
  for (k = 1; k <= myscp->no_eligible_schools[i-1]; k++) {
    j = myscp->preferences[i-1][k-1];
    answer += get_entry(alloc, i, j);
  }

  return answer;
}

double get_total_demand_for_school(partial_alloc* alloc, int j) {
  int i, nst;
  double answer;

  nst = alloc->no_students;
  
  answer = 0.0;
  for (i = 1; i <= nst; i++) {
    answer += get_entry(alloc, i, j);
  }

  return answer;
}

double* school_sums(partial_alloc* my_alloc) {
  int i, j;
  double* sums = malloc(my_alloc->no_schools * sizeof(double));
  for (j = 1; j <= my_alloc->no_schools; j++) {
    sums[j-1] = 0.0;
    for (i = 1; i <= my_alloc->no_students; i++) {
      sums[j-1] += get_entry(my_alloc, i, j);
    }
  }
  return sums;
}

double* excess_demands(process_scp* myscp, partial_alloc* demands) {
  int j, nsc;
  double total_demand;

  double* answer;
  
  nsc = myscp->no_schools;

  answer = malloc(nsc * sizeof(double));
  
  for (j = 1; j <= nsc; j++) {
    total_demand = get_total_demand_for_school(demands, j);
    answer[j-1] = total_demand - (double)myscp->quotas[j-1];
  }

  return answer;
}

double sum_of_excesses(process_scp* myscp, double* cutoffs) {
  int j, nsc;
  double excess_sum;

  double* excesses;

  partial_alloc demands;

  nsc = myscp->no_schools;
  
  demands = compute_demands(myscp, cutoffs);
    
  excesses = excess_demands(myscp, &demands);
    
  excess_sum = 0.0;
  for (j = 1; j <= nsc; j++) {
    excess_sum += max(excesses[j-1], 0.0);
  }
  /*
  for (j = 1; j <= nsc; j++) {
    if (excesses[j-1] > 0.00000000001) {
      cutoffs[j-1] = naive_eq_cutoff(myscp, j, &demands);
    }
  }
  */
  destroy_partial_alloc(demands);
  free(excesses);

  return excess_sum;
}

double* demand_deficits(process_scp* myscp, partial_alloc* demands) {
  int j;
  double total_demand;
  
  int nsc = myscp->no_schools;

  double* answer = malloc(nsc * sizeof(double));
  
  for (j = 1; j <= nsc; j++) {
    total_demand = get_total_demand_for_school(demands, j);
    answer[j-1] = (double)myscp->quotas[j-1] - total_demand;
  }

  return answer;
}

double sum_of_deficits(process_scp* myscp, double* cutoffs) {
  int j, nsc;
  double deficit_sum;

  double* deficits;

  partial_alloc demands;

  nsc = myscp->no_schools;
  
  demands = compute_demands(myscp, cutoffs);
    
  deficits = demand_deficits(myscp, &demands);
    
  deficit_sum = 0.0;
  for (j = 1; j <= nsc; j++) {
    if (cutoffs[j-1] > 0.000001) {
      deficit_sum += max(deficits[j-1], 0.0);
    }
  }

  destroy_partial_alloc(demands);
  free(deficits);

  return deficit_sum;
}

int partial_allocs_are_same(partial_alloc* first, partial_alloc* second) {
  int i, j, nst, nsc;
  double max_diff;

  nst = first->no_students;
  nsc = first->no_schools;

  max_diff = 0.0;

  for (i = 1; i <= nst; i++) {
    for (j = 1; j <= nsc; j++) {
      max_diff = max(max_diff, fabs(get_entry(first, i, j) - get_entry(second, i, j)));
      /*
      if (fabs(get_entry(first, i, j) - get_entry(second, i, j)) > 0.000001)  {

	printf("The two allocs differ with first(%i,%i) = %1.2f and second (%i,%i) = %1.2f.\n",
	       i, j, get_entry(first, i, j), i, j, get_entry(second, i, j));
	
	return 0;
      }
      */
    }
  }
  if (max_diff > 0.000001) {
    fprintf(stderr, "The max_diff is %1.8f.\n", max_diff);
    return 0;
  }

  return 1;
}

/*
int partial_allocs_are_same(partial_alloc* first, partial_alloc* second) {
  int i, j;

  int nst = first->no_students;
  int nsc = first->no_schools;

  for (i = 1; i <= nst; i++) {
    for (j = 1; j <= nsc; j++) {
      if (fabs(get_entry(first, i, j) - get_entry(second, i, j)) > 0.000001)  {

	printf("The two allocs differ with first(%i,%i) = %1.2f and second (%i,%i) = %1.2f.\n",
	       i, j, get_entry(first, i, j), i, j, get_entry(second, i, j));
	
	return 0;
      }
    }
  }

  return 1;
}
*/

int students_are_fully_allocated(partial_alloc* my_alloc, process_scp* myscp) {
  int i, k, answer;
  double sum;

  answer = 1;

  for (i = 1; i <= my_alloc->no_students; i++) {
    sum = 0.0;

    for (k = 1; k <= myscp->no_eligible_schools[i-1]; k++) {
      sum += get_entry(my_alloc, i, myscp->preferences[i-1][k-1]);
    }

    if (sum <= myscp->time_remaining - 0.000001 || sum >= myscp->time_remaining + 0.000001) {

      fprintf(stderr, "Student %i's total allocation is %1.2f.\n", i, sum);
      
      answer = 0;
    }
  }

  return answer;
}

int is_a_feasible_allocation(partial_alloc* my_alloc, process_scp* myscp) {
  int i, j;
  double sum;
  
  if (!students_are_fully_allocated(my_alloc, myscp)) {
    return 0;
  }

  for (j = 1; j <= myscp->no_schools; j++) {
    sum = 0.0;
    for (i = 1; i <= myscp->no_students; i++) {
      sum += get_entry(my_alloc, i, j);
    }
    if (sum > myscp->quotas[j-1] + 0.000001) {

      fprintf(stderr, "School %i's quota is exceeded.\n", j);
      
      return 0;
    }
  }

  return 1;
}

int is_feasible_for_input_scp(partial_alloc* my_alloc, input_sch_ch_prob* myiscp) {
  int answer;
  process_scp myscp;

  myscp = process_scp_from_input(myiscp);
  answer = is_a_feasible_allocation(my_alloc, &myscp);
  destroy_process_scp(myscp);

  return answer;
}

int is_a_feasible_pure_alloc(pure_alloc* my_alloc, input_sch_ch_prob* myiscp) {
  int i, j, nst, nsc, sum;

  nst = myiscp->no_students;
  nsc = myiscp->no_schools;

  for (i = 1; i <= nst; i++) {
    sum = 0;
    for (j = 1; j <= nsc; j++) {
      sum += get_integer_entry(my_alloc, i, j);
    }
    if (sum != 1) {
      return 0;
    }
  }

  for (j = 1; j <= nsc; j++) {
    sum = 0;
    for (i = 1; i <= nst; i++) {
      sum += get_integer_entry(my_alloc, i, j);
    }
    if (sum > myiscp->quotas[j-1]) {
      return 0;
    }
  }

  return 1;
}

int gives_some_student_nothing(partial_alloc* myalloc) {
  int i, j, nst, nsc;

  double total_prob;
  
  nst = myalloc->no_students;
  nsc = myalloc->no_schools;

  for (i = 1; i <= nst; i++) {
    total_prob = 0.0;
    for (j = 1; j <= nsc; j++) {
      total_prob += get_entry(myalloc, i, j);
    }
    if (total_prob < 0.000001) {
      return i;
    }
  }

  return 0;
}

partial_alloc zero_alloc_for_process_scp(process_scp* myscp) {
  int nst, nsc;
  
  nst = myscp->no_students;
  nsc = myscp->no_schools;
  
  partial_alloc answer;
  answer.no_students = nst;
  answer.no_schools = nsc;

  answer.sparse = new_dbl_sp_mat_for_process(myscp);
  
  return answer;
}

partial_alloc zero_alloc_for_input_scp(input_sch_ch_prob* myscp) {
  int nst, nsc;
  
  nst = myscp->no_students;
  nsc = myscp->no_schools;
  
  partial_alloc answer;
  answer.no_students = nst;
  answer.no_schools = nsc;

  answer.sparse = new_dbl_sp_mat_for_input(myscp);
  
  return answer;
}

partial_alloc translate_alloc_for_input_scp(input_sch_ch_prob* target, partial_alloc* source) {
  int i, j, k, nst;
  
  nst = target->no_students;
  
  partial_alloc answer;

  answer = zero_alloc_for_input_scp(target);

  for (i = 1; i <= nst; i++) {
    for (k = 1; k <= answer.sparse.nos_active_cols[i-1]; k++) {
      j = answer.sparse.index_of_active_cols[i-1][k-1];
      if (sch_is_active_for_stu(source, i, j)) {
	set_entry(&answer, i, j, get_entry(source, i, j));
      }
    }
  }

  return answer;  
}

pure_alloc zero_pure_alloc_for_input_scp(input_sch_ch_prob* myiscp) {

  int nst, nsc;
  
  nst = myiscp->no_students;
  nsc = myiscp->no_schools;
  
  pure_alloc answer;
  answer.no_students = nst;
  answer.no_schools = nsc;

  answer.sparse = new_int_sp_mat_for_input(myiscp);
  
  return answer;
}

partial_alloc left_sub_process_feasible_guide(partial_alloc* feasible_guide,
					    subset* J_subset, subset* P_subset) {
  int i, j, k, l, m, elt_no, new_nst, new_nsc;

  int* stu_no_key;
  int* sch_no_key;

  new_nst = J_subset->subset_size;
  new_nsc = P_subset->subset_size;

  partial_alloc new_guide;

  new_guide.no_students = new_nst;
  new_guide.no_schools = new_nsc;
  
  stu_no_key = malloc(J_subset->subset_size * sizeof(int));
  elt_no = 0;
  for (i = 1; i <= J_subset->large_set_size; i++) {
    if (J_subset->indicator[i-1] == 1) {
      elt_no++;
      stu_no_key[elt_no-1] = i;
    }
  }

  sch_no_key = malloc(P_subset->subset_size * sizeof(int));
  elt_no = 0;
  for (j = 1; j <= P_subset->large_set_size; j++) {
    if (P_subset->indicator[j-1] == 1) {
      elt_no++;
      sch_no_key[elt_no-1] = j;
    }
  }

  new_guide.sparse = zero_dbl_sp_mat_for_subsets(&(feasible_guide->sparse), J_subset, P_subset);

  for (k = 1; k <= new_nst; k++) {
    i = stu_no_key[k-1];

    for (m = 1; m <= new_guide.sparse.nos_active_cols[k-1]; m++) {
      l = new_guide.sparse.index_of_active_cols[k-1][m-1];
      j = sch_no_key[l-1];
      set_dbl_entry(&(new_guide.sparse), k, l, get_entry(feasible_guide, i, j));
    }
  }

  free(stu_no_key);
  free(sch_no_key);

  return new_guide;
}

partial_alloc right_sub_process_feasible_guide(partial_alloc* feasible_guide,
					  subset* J_subset, subset* P_subset) {
  subset J_compl;
  subset P_compl;
  partial_alloc new_guide;
  
  J_compl = complement_of_subset(J_subset);
  P_compl = complement_of_subset(P_subset);
  new_guide = left_sub_process_feasible_guide(feasible_guide, &J_compl, &P_compl);

  destroy_subset(J_compl);
  destroy_subset(P_compl);

  return new_guide;
}

void increment_partial_alloc(partial_alloc* base, partial_alloc* increment,
			     element_list* stu_index,element_list* sch_index) {
  int i,j;
  
  for (i = 1; i <= increment->no_students; i++) {
    for (j = 1; j <= increment->no_schools; j++) {

      
      increment_entry(base, stu_index->indices[i-1], sch_index->indices[j-1], get_entry(increment, i, j));
      
    }
  }
}


partial_alloc copy_of_partial_alloc(partial_alloc* given) {
  int nst, nsc;

  nst = given->no_students;
  nsc = given->no_schools;
  
  partial_alloc copy;

  copy.no_students = nst;
  copy.no_schools = nsc;

  copy.sparse = copy_of_dbl_sp_mat(&(given->sparse));

  return copy;
}

pure_alloc pure_allocation_from_partial(partial_alloc* my_alloc) {
  int i, j;
  int nst = my_alloc->no_students;
  int nsc = my_alloc->no_schools;
  
  pure_alloc my_pure;
  my_pure.no_students = nst;
  my_pure.no_schools = nsc;

  my_pure.sparse = zero_int_sp_mat_from_dbl_sp_mat(&(my_alloc->sparse));

  for (i = 1; i <= nst; i++) {
    for (j = 1; j <= nsc; j++) {
      if (get_entry(my_alloc, i, j) > 0.99999) {
	set_int_entry(&(my_pure.sparse), i, j, 1);
      }
      else {
	set_int_entry(&(my_pure.sparse), i, j, 0);
      }
    }
  }
  
  return my_pure;
}

int split_is_valid(partial_alloc* given, subset* J_subset, subset* P_subset) {
  int i, j, nst, nsc, answer;

  nst = given->no_students;
  nsc = given->no_schools;

  answer = 1;

  for (i = 1; i <= nst; i++) {
    for (j = 1; j <= nsc; j++) {
      if (!is_element(J_subset, i) && is_element(P_subset, j) && get_entry(given, i, j) > 0.0001) {
	fprintf(stderr, "Student %i outside of J is getting a positive amount of %i in P.\n",
		i, j);
	answer = 0;
      }
      if (is_element(J_subset, i) && !is_element(P_subset, j) && get_entry(given, i, j) > 0.0001) {
	fprintf(stderr, "Student %i in J is getting a positive amount of %i outside of P.\n",
		i, j);
	answer = 0;
      }
    }
  }

  return answer;
}

partial_alloc partial_allocation_from_pure(pure_alloc* my_alloc) {
  int i, j;
  int nst = my_alloc->no_students;
  int nsc = my_alloc->no_schools;
  
  partial_alloc my_partial;
  my_partial.no_students = nst;
  my_partial.no_schools = nsc;

  my_partial.sparse = zero_dbl_sp_mat_from_int_sp_mat(&(my_alloc->sparse));

  for (i = 1; i <= nst; i++) {
    for (j = 1; j <= nsc; j++) {
      set_dbl_entry(&(my_partial.sparse), i, j, (double)get_integer_entry(my_alloc, i, j));
    }
  }
  
  return my_partial;
}

int get_pure_entry(pure_alloc* alloc, int i, int j)  {
  return int_entry(&(alloc->sparse), i, j);
}

void set_pure_entry(pure_alloc* alloc, int i, int j, int val) {
  set_int_entry(&(alloc->sparse), i, j, val);
}

void increment_pure_entry(pure_alloc* alloc, int i, int j, int incr) {
  increment_int_entry(&(alloc->sparse), i, j, incr);
}

void print_partial_alloc(partial_alloc* my_alloc) {
  int i, k, l, nst, nsc, sch_no, old_sch_no;
  
  nst = my_alloc->no_students;
  nsc = my_alloc->no_schools;
  
  printf("/* This is a sample introductory comment. */\n");

  printf("There are %d students and %d schools\n",nst,nsc);

  printf("The numbers of eligible schools are\n");
  printf("(");
  for (i = 1; i <= nst - 1; i++) {
    printf("%i,", my_alloc->sparse.nos_active_cols[i-1]);
  }
  printf("%i)\n", my_alloc->sparse.nos_active_cols[nst-1]);
  printf("The lists of eligible schools are");
  for (i = 1; i <= nst; i++) {
    printf("\n");
    l = my_alloc->sparse.nos_active_cols[i-1];
    printf("%i: ", i);
    for (k = 1; k <= l - 1; k++) {
      printf("%i, ", my_alloc->sparse.index_of_active_cols[i-1][k-1]);
    }
    printf("%i", my_alloc->sparse.index_of_active_cols[i-1][l-1]);
  }
  
  printf("\nThe allocations are");
  
  for (i = 1; i <= my_alloc->no_students; i++) {
    printf("\n%i:",i);
    if (i < 10) {
      printf(" ");
    }
    old_sch_no = 0;
    for (k = 1; k <= my_alloc->sparse.nos_active_cols[i-1]; k++) {
      sch_no = my_alloc->sparse.index_of_active_cols[i-1][k-1];
      for (l = 1; l <= sch_no - old_sch_no - 1; l++) {
	printf("               ");
      }
      if (sch_no < 10) {
	printf(" ");
      }
      printf(" %i: %2.8f", sch_no, fabs(get_entry(my_alloc, i, sch_no)));
      old_sch_no = sch_no;
    }
  }
  printf("\n");
}

void fprint_partial_alloc(partial_alloc* my_alloc) {
  int i, k, l, nst, nsc, sch_no, old_sch_no;
  
  nst = my_alloc->no_students;
  nsc = my_alloc->no_schools;
  
  fprintf(stderr, "/* This is a sample introductory comment. */\n");

  fprintf(stderr, "There are %d students and %d schools\n",nst,nsc);

  fprintf(stderr, "The numbers of eligible schools are\n");
  fprintf(stderr, "(");
  for (i = 1; i <= nst - 1; i++) {
    fprintf(stderr, "%i,", my_alloc->sparse.nos_active_cols[i-1]);
  }
  fprintf(stderr, "%i)\n", my_alloc->sparse.nos_active_cols[nst-1]);
  fprintf(stderr, "The lists of eligible schools are");
  for (i = 1; i <= nst; i++) {
    fprintf(stderr, "\n");
    l = my_alloc->sparse.nos_active_cols[i-1];
    fprintf(stderr, "%i: ", i);
    for (k = 1; k <= l - 1; k++) {
      fprintf(stderr, "%i, ", my_alloc->sparse.index_of_active_cols[i-1][k-1]);
    }
    fprintf(stderr, "%i", my_alloc->sparse.index_of_active_cols[i-1][l-1]);
  }
  
  fprintf(stderr, "\nThe allocations are");
  
  for (i = 1; i <= my_alloc->no_students; i++) {
    fprintf(stderr, "\n%i:",i);
    if (i < 10) {
      fprintf(stderr, " ");
    }
    old_sch_no = 0;
    for (k = 1; k <= my_alloc->sparse.nos_active_cols[i-1]; k++) {
      sch_no = my_alloc->sparse.index_of_active_cols[i-1][k-1];
      for (l = 1; l <= sch_no - old_sch_no - 1; l++) {
	fprintf(stderr, "               ");
      }
      if (sch_no < 10) {
	fprintf(stderr, " ");
      }
      fprintf(stderr, " %i: %2.8f", sch_no, fabs(get_entry(my_alloc, i, sch_no)));
      old_sch_no = sch_no;
    }
  }
  fprintf(stderr, "\n");
}

int pure_alloc_is_valid(pure_alloc* my_pure_alloc) {
  int i, k, count;

  for (i = 1; i <= my_pure_alloc->no_students; i++) {
    count = 0;
    for (k = 1; k <= my_pure_alloc->sparse.nos_active_cols[i-1]; k++) {
      if (my_pure_alloc->sparse.entries[i-1][k-1] == 1) {
	count++;
      }
    }
    if (count != 1) {
      return 0;
    }
  }

  return 1;
}

void print_pure_alloc(pure_alloc* my_pure_alloc) {
  int i, k, done, sch_no, tencount, hundredcount;

  if (!pure_alloc_is_valid(my_pure_alloc)) {
    printf("We have an invalid pure_alloc.\n");
    exit(0);
  }
  
  printf("/* This is a sample introductory comment. */\n");

  tencount = 0;
  hundredcount = 0;
    
  for (i = 1; i <= my_pure_alloc->no_students; i++) {
    done = 0;    
    k = 1;
    while (!done) {
      if (my_pure_alloc->sparse.entries[i-1][k-1] == 1) {
	sch_no = my_pure_alloc->sparse.index_of_active_cols[i-1][k-1];
	done = 1;
      }
      else {
	k++;
      }
    }
    if (i < 10000) {
      printf(" ");
    }
    if (i < 1000) {
      printf(" ");
    }
    if (i < 100) {
      printf(" ");
    }
    if (i < 10) {
      printf(" ");
    }
    printf("%i",i);
    printf(" -> ");
    if (sch_no < 100) {
      printf(" ");
    }
    if (sch_no < 10) {
      printf(" ");
    }
    printf("%i", sch_no);
    printf(";");
    tencount++;
    if (tencount == 10) {
      printf("\n");
      tencount = 0;
    }
    hundredcount++;
    if (hundredcount == 10) {
      printf("\n");
      hundredcount = 0;
    }
  }
  printf("\n");
}

void destroy_partial_alloc(partial_alloc my_alloc) {
  destroy_dbl_sp_mat(&(my_alloc.sparse));
}

void destroy_pure_alloc(pure_alloc my_pure_alloc) {
  destroy_int_sp_mat(&(my_pure_alloc.sparse));
}
