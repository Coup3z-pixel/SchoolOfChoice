#ifndef GCPSA_h
#define GCPSA_h

#include "mcccode.h"
#include "gcpscode.h"

struct partial_alloc gcpsa_allocation(struct process_scp* myscp);

#endif /* GCPSA_H */
