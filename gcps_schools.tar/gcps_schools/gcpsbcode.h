#ifndef GCPSB_h
#define GCPSB_h

#include "mcccode.h"
#include "gcpscode.h"

struct partial_alloc gcpsb_allocation(struct process_scp* myscp);

#endif /* GCPSB_H */
