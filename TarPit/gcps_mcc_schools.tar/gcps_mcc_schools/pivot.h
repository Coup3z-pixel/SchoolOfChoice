#ifndef PIVOT_H
#define PIVOT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pushrelabel.h"

struct pivot {
  int h;
  int* schools;
  int* students;
};

struct pivot_list_node {
  struct pivot* the_pivot;
  struct pivot_list_node* next;
};

struct pivot_list {
  struct pivot_list_node* first_node;
  struct pivot_list_node* last_node;
};

struct pivot initialized_pivot(int h);

struct pivot_list void_pivot_list();

struct pivot* copy_of_pivot(struct pivot* my_pivot);

int pivot_list_is_void(struct pivot_list* my_list);

void add_pivot_to_list(struct pivot_list* my_list, struct pivot* new_pivot);

void concatenate_pivot_lists(struct pivot_list* target, struct pivot_list* addition);

void execute_pivot(struct pivot* my_pivot, int** theta, int* theta_sums);

struct pivot_list reduced_pivot_list(struct pivot_list* given_list,
				     struct subset* J_subset, struct subset* P_subset);

struct pivot_list left_reduced_pivot_list(struct pivot_list* given_list,
					  struct subset* J_subset, struct subset* P_subset);

struct pivot_list right_reduced_pivot_list(struct pivot_list* given_list,
					   struct subset* J_subset, struct subset* P_subset);


void destroy_pivot(struct pivot my_pivot);

void destroy_pivot_ptr(struct pivot* my_pivot);

void destroy_pivot_list_node(struct pivot_list_node my_pivot_list_node);

void destroy_pivot_list(struct pivot_list my_pivot_list);

#endif /* PIVOT_H */
